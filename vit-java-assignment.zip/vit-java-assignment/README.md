# VIT Java Assignment — Spring Boot Auto-run App
## Run Instructions
1. Update `src/main/resources/application.yml` with your candidate info.
2. Build with `mvn clean package`.
3. Run with `java -jar target/vit-java-assignment-0.0.1-SNAPSHOT.jar`.
4. H2 console: http://localhost:8080/h2-console
