package com.vit.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import com.vit.assignment.config.AppProps;

@SpringBootApplication
@EnableConfigurationProperties(AppProps.class)
public class VitJavaAssignmentApplication {
    public static void main(String[] args) {
        SpringApplication.run(VitJavaAssignmentApplication.class, args);
    }
}