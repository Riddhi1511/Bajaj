package com.vit.assignment.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
public class AppProps {
    private Candidate candidate = new Candidate();
    private Endpoints endpoints = new Endpoints();
    private Question question = new Question();
    public Candidate getCandidate() { return candidate; }
    public Endpoints getEndpoints() { return endpoints; }
    public Question getQuestion() { return question; }
    public static class Candidate { public String name; public String regNo; public String email; }
    public static class Endpoints { public String generateWebhook; public String testWebhook; }
    public static class Question { public String oddLink; public String evenLink; }
}