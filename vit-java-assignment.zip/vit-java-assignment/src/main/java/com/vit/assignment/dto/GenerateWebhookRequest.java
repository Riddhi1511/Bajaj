package com.vit.assignment.dto;
public class GenerateWebhookRequest {
    public String name; public String regNo; public String email;
    public GenerateWebhookRequest() {}
    public GenerateWebhookRequest(String name, String regNo, String email) {
        this.name=name; this.regNo=regNo; this.email=email;
    }
}