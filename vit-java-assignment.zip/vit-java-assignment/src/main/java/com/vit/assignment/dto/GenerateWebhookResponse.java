package com.vit.assignment.dto;
public class GenerateWebhookResponse {
    public String webhook; public String accessToken;
}