package com.vit.assignment.entity;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="final_answer")
public class FinalAnswer {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String regNo;
    @Column(length=4000) private String finalQuery;
    private Instant savedAt;
    public FinalAnswer() {}
    public FinalAnswer(String regNo,String finalQuery,Instant savedAt){
        this.regNo=regNo;this.finalQuery=finalQuery;this.savedAt=savedAt;
    }
}