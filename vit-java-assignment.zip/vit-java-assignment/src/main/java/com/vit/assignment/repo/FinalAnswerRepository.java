package com.vit.assignment.repo;
import com.vit.assignment.entity.FinalAnswer;
import org.springframework.data.jpa.repository.JpaRepository;
public interface FinalAnswerRepository extends JpaRepository<FinalAnswer, Long> {}