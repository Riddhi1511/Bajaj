package com.vit.assignment.runner;

import com.vit.assignment.config.AppProps;
import com.vit.assignment.dto.GenerateWebhookRequest;
import com.vit.assignment.dto.GenerateWebhookResponse;
import com.vit.assignment.entity.FinalAnswer;
import com.vit.assignment.repo.FinalAnswerRepository;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments; import org.springframework.boot.ApplicationRunner;
import org.springframework.http.*; import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.io.InputStream; import java.nio.charset.StandardCharsets; import java.time.Instant; import java.util.Map;

@Component
public class BootFlow implements ApplicationRunner {
    private final Logger logger = LoggerFactory.getLogger(BootFlow.class);
    private final RestTemplate restTemplate; private final FinalAnswerRepository repo; private final AppProps props;
    public BootFlow(RestTemplate rt, FinalAnswerRepository repo, AppProps props){this.restTemplate=rt;this.repo=repo;this.props=props;}
    @Override
    public void run(ApplicationArguments args){
        logger.info("BootFlow starting...");
        GenerateWebhookResponse gen=generateWebhook();
        if(gen==null||gen.accessToken==null){logger.error("No token");return;}
        String sqlFile=isLastTwoDigitsOdd(props.getCandidate().regNo)?"answers/odd.sql":"answers/even.sql";
        String finalSql=load(sqlFile); if(finalSql==null){logger.error("No SQL");return;}
        repo.save(new FinalAnswer(props.getCandidate().regNo,finalSql,Instant.now()));
        submit(gen.accessToken,finalSql);
        logger.info("Finished");}
    private GenerateWebhookResponse generateWebhook(){try{String url=props.getEndpoints().generateWebhook;
        HttpHeaders h=new HttpHeaders();h.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<GenerateWebhookRequest> e=new HttpEntity<>(new GenerateWebhookRequest(props.getCandidate().name,props.getCandidate().regNo,props.getCandidate().email),h);
        ResponseEntity<GenerateWebhookResponse> r=restTemplate.exchange(url,HttpMethod.POST,e,GenerateWebhookResponse.class);
        return r.getBody();}catch(Exception ex){logger.error("gen error",ex);}return null;}
    private void submit(String token,String sql){try{HttpHeaders h=new HttpHeaders();h.setContentType(MediaType.APPLICATION_JSON);h.set("Authorization",token);
        HttpEntity<Map<String,String>> e=new HttpEntity<>(Map.of("finalQuery",sql),h);
        ResponseEntity<String> r=restTemplate.postForEntity(props.getEndpoints().testWebhook,e,String.class);
        logger.info("Submit status {} body {}",r.getStatusCode(),r.getBody());}catch(Exception ex){logger.error("submit error",ex);}}
    private boolean isLastTwoDigitsOdd(String regNo){String d=regNo.replaceAll("\\D+","");if(d.length()==0)return false;String l=d.length()>=2?d.substring(d.length()-2):d;return Integer.parseInt(l)%2==1;}
    private String load(String path){try(InputStream in=getClass().getClassLoader().getResourceAsStream(path)){return new String(in.readAllBytes(),StandardCharsets.UTF_8);}catch(Exception ex){return null;}}}
